document.getElementById("loginForm").addEventListener("submit", function(event){
    event.preventDefault();
    const username = document.getElementById("uname").value;
    const password = document.getElementById("pass").value;

    alert(`Username: ${username}\nPassword: ${password}`);
});

document.getElementById("signupForm").addEventListener("submit", function(event){
    event.preventDefault();
    const newUsername = document.getElementById("new-username").value;
    const newEmail = document.getElementById("new-email").value;
    const newPassword = document.getElementById("new-password").value;

    alert(`Username: ${newUsername}\nEmail: ${newEmail}\nPassword: ${newPassword}`);
});

function toggleForm(formType) {
    const loginFormContainer = document.getElementById("loginFormContainer");
    const signupFormContainer = document.getElementById("signupFormContainer");

    if (formType === "signup") {
        loginFormContainer.style.display = "none";
        signupFormContainer.style.display = "block";
    } else {
        signupFormContainer.style.display = "none";
        loginFormContainer.style.display = "block";
    }
}
